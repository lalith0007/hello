package com.testng;

import org.helper.BaseClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Listener extends BaseClass{
	
	

	@Test
	private void tc() {
		System.out.println("Test case 1 ");

	}
	
	
	@Test
	private void tc2() {
		
		Assert.assertTrue(false);
		System.out.println("Test case 2 ");

	}
	
	@Test
	private void tc3() {
		System.out.println("Test case 3 ");

	}

}
