package com.testng;

import org.helper.BaseClass;
import org.loc.LoginPojo;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Dataprovider extends BaseClass {

	@Test
	private void tc1() {

		chromedriver();

	}

	@Test(dataProvider = "Testdata")
	private void tc2(String email, String password) {

		urlsetup("https://www.facebook.com");

		LoginPojo l = new LoginPojo();

		sendkey(l.getUser(), email);
		sendkey(l.getPassword(), password);

		click(l.getLogin());

	}

	@DataProvider(name = "Testdata")

	private Object[][] data() {

		return new Object[][] {

				{ "lalith", "1324225" },

				{ "udjhaykdj", "454646541" },

				{ "hdjkfhjkd", "dkjfkljjk4541654156165" },

				{ "udjhaykdj", "454646541" },

				{ "udjhaykdj", "4546466546546546546545645641j4541" }

		};

	}

}
