package com.testng;

import org.helper.BaseClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Rerun extends BaseClass{
	
	
	@Test
	private void tc() {
		System.out.println("Test case 1 ");

	}
	
	
	@Test(retryAnalyzer = Failed.class)
	private void tc2() {
		
		System.out.println("test case 2.");
		Assert.assertTrue(false);
		System.out.println("Test case 2 ");

	}
	
	@Test
	private void tc3() {
		System.out.println("Test case 3 ");

	}
	
}
