package com.testng;

import org.helper.BaseClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Crossbrowser extends BaseClass {

	String st = "firefox";

	@BeforeMethod
	private void tc4() {
		chromedriver();

	}

	@Test
	private void tc1() {

		if (st.contains("fire")) {

			urlsetup("https://www.google.com/");

		}

		else {

			System.out.println("Firefox is not present ");

		}

	}

	String st1 = "chro";

	@Test
	private void tc2() throws InterruptedException {

		Thread.sleep(3000);

		if (st1.contains("ch")) {

			urlsetup("https://www.flipkart.com/");
		} else {

			System.out.println("chrome is not present");
		}

	}

	@AfterMethod
	private void tc5() {
		closedriver();
	}

}
