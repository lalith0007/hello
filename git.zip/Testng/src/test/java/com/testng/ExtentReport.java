package com.testng;

import org.helper.BaseClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {

	
	
		public static void main(String[] args) {
			
			
			ExtentSparkReporter reporter = new ExtentSparkReporter("C:\\Users\\srs\\Desktop\\Testng\\Report\\rpt.html");
			
			ExtentReports extent = new ExtentReports();
			
			
			extent.attachReporter(reporter);
			
			
			ExtentTest test = extent.createTest("TC001 - Search prodruc");
			
			test.pass("Enter the desired product name");
			
			test.pass("Check if the product is listed");
			
			test.fail("Add the product to the cart ");
			
			extent.flush();
			
			
		}
	
	
	
}
