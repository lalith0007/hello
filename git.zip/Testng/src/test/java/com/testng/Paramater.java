package com.testng;

import org.helper.BaseClass;
import org.loc.LoginPojo;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Paramater extends BaseClass  {
	
	
	@Test 
	private void tc1() {
		
		
		chromedriver();
		urlsetup("https://www.facebook.com");
		
	}

	@Parameters ({"user" , "password"})
	@Test
	private void tc2(String email , String password) {
		
		LoginPojo l = new LoginPojo();
		
		sendkey(l.getUser(), email);
		sendkey(l.getPassword() , password);
		
		click(l.getLogin());
		
		
	}
	
}
