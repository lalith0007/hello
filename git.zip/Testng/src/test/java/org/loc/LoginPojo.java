package org.loc;

import org.helper.BaseClass;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPojo extends BaseClass {

	public LoginPojo() {

		PageFactory.initElements(driver, this);

	}

	@FindBy(id = "email")
	private WebElement user;

	@FindBy(id = "pass")
	private WebElement password;

	@FindBy(name = "login")
	private WebElement login;

	@FindBy(xpath = "/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input")
	private WebElement googlesearchbox;

	@FindBy(id = "fullName")
	private WebElement name;

	public WebElement getName() {
		return name;
	}

	public WebElement getUser() {
		return user;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getLogin() {
		return login;
	}

	public WebElement getGooglesearchbox() {
		return googlesearchbox;
	}

}
