
package org.helper;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

@SuppressWarnings("deprecation")
public class BaseClass {
	// webdriver interface
	public static WebDriver driver;

	// 1 ChromeDriver
	public static void chromedriver() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

	}

	// 2 Firefox Driver
	public static void firefoxdriver() {
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
	}

	// 3 EdgeDriver
	public static void edgedriver() {
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
	}

	// 4 URL Launch
	public static void urlsetup(String url) {
		driver.get(url);
	}

	// 5 Maximize
	public static void MaxWindow() {
		driver.manage().window().maximize();
	}

	// 6 Minimize
	public static void MinWindow() {
		driver.manage().window().minimize();
	}

	// Actions class
	public static Actions actionsClass(WebDriver driver) {
		Actions act = new Actions(driver);
		return act;
	}

	// 7 MoveToElement with webelement target
	public static void movetoEle(WebElement a) {
		actionsClass(driver).moveToElement(a).perform();
	}

	// 8 dragAndDrop with WebElement target
	public static void dragDrop(WebElement a, WebElement b) {
		actionsClass(driver).dragAndDrop(a, b).perform();
	}

	// 9 keyUp with WebElement target
	public static void keyup(WebElement a, String b) {
		actionsClass(driver).keyUp(a, b).perform();
	}

	// 10 keyDown with webelement target
	public static void keydown(WebElement a, String b) {
		actionsClass(driver).keyDown(a, b).perform();
	}

	// 11 doubleClick with WebElement target
	public static void doubletimeclick(WebElement a) {
		actionsClass(driver).doubleClick(a).perform();
	}

	// 12 contextClick with webelement target
	public static void rightclick(WebElement a) {
		actionsClass(driver).contextClick(a).perform();
	}

	// 13 contextClick without webelement target
	public static void rightclkwithoutwebelementtarget() {
		actionsClass(driver).contextClick().perform();
	}

	// 14 doubleClick without webelement target
	public static void doubleclickwithoutwebelementTarget() {
		actionsClass(driver).doubleClick().perform();
	}

	// 15 Actions class click without webelement target
	public static void clickwithoutTarget() {
		actionsClass(driver).click().perform();
	}

	// 16 actions class click with webelement target
	public static void actionclickwithTarget(WebElement a) {
		actionsClass(driver).click(a).perform();
	}

	// webelement
	public static WebElement ele;

	// 17 webelement click
	public static void click(WebElement ele) {
		ele.click();
	}

	// 18 webelement sendkeys
	public static void sendkey(WebElement ele, String a) {
		ele.sendKeys(a);
	}

	// 19 webelement getAttribute
	public static void attribute() {
		String a = ele.getAttribute("value");
		System.out.println("GetAttribute :" + a);
	}

	// 20 Webelement getText
	public static String text(WebElement ele) {
		String a = "";
		a = ele.getText();
		return a;
	}

	// 21 webelement submit
	public static void submitbutton() {
		ele.submit();
	}

	// Alert
	public static Alert alertInterface() {
		Alert ala = driver.switchTo().alert();
		return ala;
	}

	// 22 Alert accept
	public static void alertaccept() {
		alertInterface().accept();
	}

	// 23 alert dismiss
	public static void alertdismiss() {
		alertInterface().dismiss();
	}

	// 24 alert getText
	public static void alerttext() {
		String a = alertInterface().getText();
		System.out.println("Alert get text: " + a);
	}

	// 25alat sendkeys
	public static void alertsendkey(String a) {
		alertInterface().sendKeys(a);
	}

	// screnshot
	public static TakesScreenshot takeSS() {
		TakesScreenshot tak = (TakesScreenshot) driver;
		return tak;
	}

	// 26 getScreenshot
	public static void screenshottoget() {
		takeSS().getScreenshotAs(OutputType.FILE);
	}

	// file
	public static File fil;

	// 27 create one folder
	public static void onefolder() {
		fil.mkdir();
	}

	// 28 create multiple folder
	public static void multifolder() {
		fil.mkdirs();
	}

	// 29 used to create file
	public static void createFile() throws IOException {
		fil.createNewFile();
	}

	// FileUtils class
	// 30 to check the file can readed
	public void read() {
		boolean a = fil.canRead();
		System.out.println("can read: " + a);
	}

	// 31 to check the file can be writed
	public static void write() {
		boolean a = fil.canWrite();
		System.out.println("can write: " + a);
	}

	// 32 to copy file
	public static void copyfile(File a, File b) throws IOException {
		FileUtils.copyFile(a, b);
	}

	// robot class
	public static Robot robotClass() throws AWTException {
		Robot robo = new Robot();
		return robo;
	}

	// 33 robot class Up key
	public static void robotup() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_UP);
		robotClass().keyRelease(KeyEvent.VK_UP);
	}

	// 34 Robot class Down Key
	public static void robotdown() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_DOWN);
		robotClass().keyRelease(KeyEvent.VK_DOWN);
	}

	// 35 robot class page up
	public static void robotpageup() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_PAGE_UP);
		robotClass().keyRelease(KeyEvent.VK_PAGE_UP);
	}

	// 36 robot class page down
	public static void robotpagedown() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_PAGE_DOWN);
		robotClass().keyRelease(KeyEvent.VK_PAGE_DOWN);
	}

	// 37 robot class enter
	public static void robotenter() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_ENTER);
		robotClass().keyRelease(KeyEvent.VK_ENTER);
	}

	// 38 robot class select all
	public static void robotselectall() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_CONTROL);
		robotClass().keyPress(KeyEvent.VK_A);
		robotClass().keyRelease(KeyEvent.VK_A);
		robotClass().keyRelease(KeyEvent.VK_CONTROL);
	}

	// 39 robot class copy
	public static void robotcopy() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_CONTROL);
		robotClass().keyPress(KeyEvent.VK_C);
		robotClass().keyRelease(KeyEvent.VK_C);
		robotClass().keyRelease(KeyEvent.VK_CONTROL);
	}

	// 40 robot class copy
	public static void robotcut() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_CONTROL);
		robotClass().keyPress(KeyEvent.VK_X);
		robotClass().keyRelease(KeyEvent.VK_X);
		robotClass().keyRelease(KeyEvent.VK_CONTROL);
	}

	// 41 robot class paste
	public static void robotpaste() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_CONTROL);
		robotClass().keyPress(KeyEvent.VK_V);
		robotClass().keyRelease(KeyEvent.VK_V);
		robotClass().keyRelease(KeyEvent.VK_CONTROL);
	}

	// 42 robot class press tab
	public static void robottab() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_TAB);
		robotClass().keyRelease(KeyEvent.VK_TAB);
	}

	// 43 robot class inspect
	public static void robotinspect() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_F12);
		robotClass().keyRelease(KeyEvent.VK_F12);
	}

	// javascript executor
	public static JavascriptExecutor jsScript() {
		JavascriptExecutor jav = (JavascriptExecutor) driver;
		return jav;
	}

	// 44 scroll down
	public static void jsscroldown(WebElement a) {
		jsScript().executeScript("arguments[0].scrollIntoView(true)" + a);
	}

	// 45 scroll up
	public static void jsscrolup(WebElement a) {
		jsScript().executeScript("arguments[0].scrollIntoView(false)" + a);
	}

	// 46 javascript sendkeys
	public static void jsSendkeys(String c, WebElement a) {
		jsScript().executeScript("arguments[0].setAttribute('value','" + c + "')" + a);
	}

	// 47 javascript click
	public static void jsClick(WebElement a) {
		jsScript().executeScript("arguments[0].click()" + a);
	}

	// 48 javascript getAttribute
	public static void jsGetAttribute(WebElement a) {
		jsScript().executeScript("return arguments[0].getAttribute('value')" + a);
	}

	// 49 close
	public static void closedriver() {
		driver.close();
	}

	// 50 quit
	public static void quitdriver() {
		driver.quit();
	}

	// 51 DATADRIVEN read from excel
	public static String xlreadData(String s, String n, int row, int cell) throws IOException {
		File f = new File(s);
		FileInputStream fin = new FileInputStream(f);
		Workbook book = new XSSFWorkbook(fin);
		Sheet sh = book.getSheet(n);
		Row r = sh.getRow(row);
		Cell c = r.getCell(cell);
		int type = c.getCellType();
		String name = "";
		if (type == 1) {
			name = c.getStringCellValue();
		} else if (DateUtil.isCellDateFormatted(c)) {
			Date d = c.getDateCellValue();
			SimpleDateFormat sim = new SimpleDateFormat("dd-MM-yyyy");
			name = sim.format(d);
		} else {
			double val = c.getNumericCellValue();
			long l = (long) val;
			name = String.valueOf(l);
		}
		return name;
	}

	// 52 DATADRIVEN CREATE NEW EXCEL
	public static void xlcreateExcel(String store, String nam, int irow, int icel, String a) throws IOException {
		// create new file
		File f = new File(store);
		// create new workbook
		Workbook book = new XSSFWorkbook();
		// create new sheet
		Sheet sh = book.createSheet(nam);
		// create a row
		Row rr = sh.createRow(irow);
		// create cell
		rr.createCell(icel).setCellValue(a);
		// output stream
		FileOutputStream fo = new FileOutputStream(f);
		book.write(fo);
		System.out.println("New Excel created with Data");
	}

	// 53 DATADRIVEN ADD NEW CELL VALUE
	public static void xladdCell(String store, String sheet, int i1, int ci, String a) throws IOException {
		File f = new File(store);
		FileInputStream fi = new FileInputStream(f);
		Workbook book = new XSSFWorkbook(fi);
		Sheet sh = book.getSheet(sheet);
		Row r1 = sh.getRow(i1);
		r1.createCell(ci).setCellValue(a);
		FileOutputStream fo = new FileOutputStream(f);
		book.write(fo);
		System.out.println("New Cell Added and Cell value Added");
	}

	// 54 implicit wait
	public static void waitimplicit() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	// 55 refresh
	public static void robotrefresh() throws AWTException {
		robotClass().keyPress(KeyEvent.VK_F5);
		robotClass().keyRelease(KeyEvent.VK_F5);
	}

	// 56 ADD NEW ROW
	public static void xladdRow(String store, String nam, int irow, int ic, String a) throws IOException {
		File f = new File(store);
		FileInputStream fin = new FileInputStream(f);
		// create new workbook
		Workbook book = new XSSFWorkbook(fin);
		// create new sheet
		Sheet sh = book.getSheet(nam);
		// create a row
		Row rr = sh.createRow(irow);
		// create cell
		rr.createCell(ic).setCellValue(a);
		// output stream
		FileOutputStream fo = new FileOutputStream(f);
		book.write(fo);
		System.out.println("New Row Added");
	}

	// 57 Update old cell value to New
	public static void xlUpdateCell(String store, String sheet, int ir, int ic, String oldval, String NewVal)
			throws IOException {
		File f = new File(store);
		FileInputStream fin = new FileInputStream(f);
		Workbook book = new XSSFWorkbook(fin);
		Sheet sh = book.getSheet(sheet);
		Row r = sh.getRow(ir);
		Cell c = r.createCell(ic);
		String value = c.getStringCellValue();
		if (value.contains(oldval)) {
			c.setCellValue(NewVal);
		}
		FileOutputStream fout = new FileOutputStream(f);
		book.write(fout);
		System.out.println("old cell value to new value updated");
	}

	// Select (DropDown)
	public static Select selectClass(WebElement ele) {
		Select s = new Select(ele);
		return s;
	}

	// 58 selectByValue
	public static void selectValue(WebElement ele, String a) {
		selectClass(ele).selectByValue(a);
	}

	// 59 selectByIndex
	public static void selectIndex(WebElement ele, int a) {
		selectClass(ele).selectByIndex(a);
	}

	// 60 selectByVisibleText
	public static void selectVisibleText(WebElement ele, String a) {
		selectClass(ele).selectByVisibleText(a);
	}

	// 61 getOptions
	public static void selectgetOption(WebElement ele) {
		List<WebElement> opp = selectClass(ele).getOptions();
		for (WebElement we : opp) {
			String t = we.getText();
			System.out.println(t);
		}
	}

	// 62 getAllSelectedOptions
	public static void allSelectOption(WebElement ele) {
		List<WebElement> allOpp = selectClass(ele).getAllSelectedOptions();
		for (WebElement we : allOpp) {
			String t = we.getText();
			System.out.println(t);
		}
	}

	// 63 deSelectValue
	public static void deSelectValue(WebElement ele, String a) {
		selectClass(ele).deselectByValue(a);
	}

	// 64 deSelectIndex
	public static void deSelectIndex(WebElement ele, int i) {
		selectClass(ele).deselectByIndex(i);
	}

	// 65 deSelectByText
	public static void deSelectText(WebElement ele, String t) {
		selectClass(ele).deselectByVisibleText(t);
	}

	// 66 deSelectAll
	public static void deSelectAll(WebElement ele) {
		selectClass(ele).deselectAll();
	}

	// 67 ReadAlData in Excel
	public static void xlreadAlldata(String file, String sheet) throws IOException {

		File f = new File(file);

		FileInputStream fin = new FileInputStream(f);

		Workbook book = new XSSFWorkbook(fin);

		Sheet sh = book.getSheet(sheet);

		for (int i = 0; i < sh.getPhysicalNumberOfRows(); i++) {

			Row r = sh.getRow(i);

			for (int j = 0; j < r.getPhysicalNumberOfCells(); j++) {

				Cell c = r.getCell(j);

				int type = c.getCellType();

				if (type == 1) {

					String value1 = c.getStringCellValue();

					System.out.println(value1);

				}

				else if (DateUtil.isCellDateFormatted(c)) {

					Date d = c.getDateCellValue();
					SimpleDateFormat sim = new SimpleDateFormat("dd-MM-yyyy");
					String value2 = sim.format(d);
					System.out.println(value2);

				}

				else {

					double d = c.getNumericCellValue();

					long l = (long) d;

					String value3 = String.valueOf(l);

					System.out.println(value3);
				}
			}
		}
	}

	// 68 OperaDriver
	public static void operadriver() {
		WebDriverManager.operadriver().setup();
		driver = new OperaDriver();
	}
}